This is a basic brute force method to iterate over a data set and find the element with the greatest value.

The data was generated with a python script that just writes out an array of years from 1900 to 2000.

The array is written to the Dataset.h header so regenerating the data would require a recompile of the executable.

It could easily be changed to have the executable read the file as binary or a csv and iterate over it this way as well.

I just used python as an example of another language the CDC has several csv files of birth and death statistics that could be used.

The brute force method should be O(n) for setting the delta values and then searching for the max value.

It could be improved to O(1) with O(n) still as a worst case if a hash map was used instead.  

The python script sorts the array which could be moved to the executable as it would run faster and would be used if reading csv files.

This method actually demonstrates the entropy inherent in most random functions.  Without weighted distribution the entropy is very near 50 percent

so no matter how many entries are generated there is an almost 100 percent chance that the middle element of the array will be the most populated.

in this case 1949.
