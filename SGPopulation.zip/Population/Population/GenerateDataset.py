#! python3
import os
import sys
import random

#-------------------------------------------------------------------------------
def generate():
	'''Simple list generator. Could add args for rnage and N-elements'''
	datearray = []
	for y in range( 1000000 ):
		datearray.append( sorted([random.randint( 1900, 2000), random.randint( 1900, 2000)]) )

	return datearray

#-------------------------------------------------------------------------------
def main(argv=None):
	'''Main entry point'''
	dates = generate()
	dates.sort( key = lambda x:x[0] )
	output_file = open( 'Dataset.h', 'w' )
	initString = 'int Dataset[{0}][{1}] = {{'.format(len(dates), 2)
	print( initString, file = output_file )
	for start_end in dates:
		element = str(start_end)
		print( '{', element.strip('[]'), '},', file = output_file )
	print( '};', file = output_file )
	
	return 0
	
#-------------------------------------------------------------------------------
if __name__ == '__main__':
    sys.exit(main())