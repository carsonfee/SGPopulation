// Population.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Dataset.h"

#define CENTURY 101 //extra element for the year 2000 
#define BASE_YEAR 1900

int main()
{
   const int datesSize = sizeof(Dataset) / sizeof(Dataset[0]);
   int years[CENTURY] = { 0 };
   int mostpopulated = 0;
   int year = 0;
   int alive = 0;
   //naive brute force method
   //just add/delete 1 for every birth/death in a year
   for (int i = 0; i < datesSize; ++i)
   {
      years[Dataset[i][0] - BASE_YEAR] += 1 ; // Log a birth
      years[Dataset[i][1] - BASE_YEAR] -= 1; //subtract a death
   }

   //run over the years and find the element with the greatest value
   for (int i = 0; i < (CENTURY - 1); ++i)
   {
      alive += years[i];
      if (alive > mostpopulated)
      {
         mostpopulated = alive;
         year = BASE_YEAR + i;
      }
      years[i] = alive;
      printf("Year : %i | Population : %i \n", BASE_YEAR + i, years[i]);
   }
   
   printf("For the Dataset with %i entries.\nThe greatest population value is : %i \n", datesSize, mostpopulated);
   printf("Year : %i had the greatest population\n", year);

   return 0;
}

