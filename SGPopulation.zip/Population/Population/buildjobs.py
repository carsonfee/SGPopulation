#!/bin/env python33
import argparse
import os
import sys

#-------------------------------------------------------------------------------
def parse_args(arguments):
    '''Parse the arguments to the program.'''
    
    parser = argparse.ArgumentParser(description='Create a submit file for')
    parser.add_argument('--output', metavar='FILE', dest='output_filename', action='store', help='Output filename')
    parser.add_argument('--submit-header', metavar='FILE', dest='submit_header', required=True, action='store', help='HTCondor submit file boilerplate header')
    parser.add_argument('--platform-list', metavar='FILE', dest='platform_list', required=True, action='store', help='List of platforms to build')
    parser.add_argument('--changelist', metavar='NUMBER', dest='changelist', required=True, action='store', help='Changelist for the jobs')
    parsed_args = parser.parse_args(arguments)

    return parsed_args

#-------------------------------------------------------------------------------
def main(argv=None):
    '''Main entry point'''
    
    if argv is None:
        argv = sys.argv
    parsed_args = parse_args(argv[1:])
    assert os.path.isfile(parsed_args.submit_header)
    assert os.path.isfile(parsed_args.platform_list)

    platforms = []
    with open(parsed_args.platform_list, 'r') as input_obj:
        for line in input_obj:
            line = line.strip()
            if line:
                platforms.append(line)

    if parsed_args.output_filename:
        output_obj = open(parsed_args.output_filename, 'w')
    else:
        output_obj = sys.stdout

    with open(parsed_args.submit_header, 'r') as input_obj:
        header_string = input_obj.read()

    output_obj.write(header_string)
    print('output = build_kyoto_game.$(Process).stdout', file=output_obj)
    print('error = build_kyoto_game.$(Process).stderr', file=output_obj)
    for platform in platforms:
        print('requirements = HasKyotoLightMapDepot', file=output_obj)
        print('arguments =', parsed_args.changelist, platform, file=output_obj)
        print('queue', file=output_obj)
    return 0

#-------------------------------------------------------------------------------
if __name__ == '__main__':
    sys.exit(main())
